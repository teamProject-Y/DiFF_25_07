package com.example.demo.vo;


public class Like {

	private int id;
	private int memberId;
	private int boardId;
}
