package com.example.demo.vo;

import java.time.LocalDateTime;

public class Board {

	private int id;
	private LocalDateTime regDate;
	private LocalDateTime updateDate;
	private String code;
	private String name;
	private boolean delStatus;
	private LocalDateTime delDate;
}
